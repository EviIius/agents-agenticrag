import { test, expect, type Page } from "@playwright/test";
import { readFile } from "node:fs/promises";
import { openTools } from "./helpers";

const original = await readFile(
  "../server/tests/fixtures/images/fake-synthetic.png",
);
const file = {
  name: "Synthetic-camera-photo.png",
  mimeType: "image/png",
  buffer: original,
};
const endpoint = "**/api/chats/*/image-references";
const unreadable = {
  status: 422,
  contentType: "application/json",
  body: JSON.stringify({
    error: { code: "image_unreadable", message: "Synthetic codec failure" },
  }),
};

async function choose(page: Page) {
  await page.goto("/");
  await openTools(page);
  const chooser = page.waitForEvent("filechooser");
  await page.getByRole("menuitem", { name: "Edit photo", exact: true }).click();
  await (await chooser).setFiles(file);
}

test("an unreadable camera upload converts automatically and preserves its original", async ({
  page,
}) => {
  const uploads: FormData[] = [];
  await page.route(endpoint, async (route) => {
    const request = route.request();
    const body = new Response(new Uint8Array(request.postDataBuffer()!), {
      headers: { "Content-Type": request.headers()["content-type"] },
    });
    uploads.push(await body.formData());
    if (uploads.length === 1) await route.fulfill(unreadable);
    else await route.continue();
  });
  await choose(page);
  await expect(page.locator('[data-slot="photo-reference"]')).toContainText(
    "Ready",
  );
  expect(uploads).toHaveLength(2);
  for (const form of uploads) {
    const source = form.get("file") as File;
    expect(Buffer.from(await source.arrayBuffer())).toEqual(original);
  }
  expect(uploads[0].get("browser_preview")).toBeNull();
  const fallback = uploads[1];
  const preview = fallback.get("browser_preview") as File;
  const bytes = Buffer.from(await preview.arrayBuffer());
  expect(bytes.subarray(0, 8).toString("hex")).toBe("89504e470d0a1a0a");
  expect(bytes.readUInt32BE(16)).toBeLessThanOrEqual(2048);
  expect(bytes.readUInt32BE(20)).toBeLessThanOrEqual(2048);
  expect(Number(fallback.get("original_width"))).toBeGreaterThan(0);
  expect(Number(fallback.get("original_height"))).toBeGreaterThan(0);
  await page
    .getByRole("textbox", { name: "Photo edit instruction" })
    .fill("Synthetic instruction stays editable");
  await expect(
    page.getByRole("button", { name: "Edit photo", exact: true }),
  ).toBeEnabled();
});

test("a failed conversion is bounded to one retry and keeps the chosen photo", async ({
  page,
}) => {
  let calls = 0;
  await page.route(endpoint, (route) => {
    calls += 1;
    return route.fulfill(unreadable);
  });
  await choose(page);
  await expect(page.locator('[data-slot="photo-reference"]')).toContainText(
    "Synthetic codec failure",
  );
  expect(calls).toBe(2);
  await expect(
    page.getByRole("button", { name: "Retry photo upload" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Edit photo", exact: true }),
  ).toBeDisabled();
});

test("permission errors do not trigger conversion or another upload", async ({
  page,
}) => {
  let calls = 0;
  await page.route(endpoint, (route) => {
    calls += 1;
    return route.fulfill({
      status: 404,
      contentType: "application/json",
      body: JSON.stringify({
        error: { code: "not_found", message: "Synthetic missing chat" },
      }),
    });
  });
  await choose(page);
  await expect(page.locator('[data-slot="photo-reference"]')).toContainText(
    "Synthetic missing chat",
  );
  expect(calls).toBe(1);
});

test("cancelling during browser conversion cannot submit or restore the removed photo", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const decode = HTMLImageElement.prototype.decode;
    const state = window as unknown as {
      photoDecoded: boolean;
      releasePhoto: () => void;
    };
    HTMLImageElement.prototype.decode = async function () {
      await decode.call(this);
      state.photoDecoded = true;
      await new Promise<void>((resolve) => {
        state.releasePhoto = resolve;
      });
    };
  });
  let calls = 0;
  await page.route(endpoint, (route) => {
    calls += 1;
    return route.fulfill(unreadable);
  });
  await choose(page);
  await page.waitForFunction(
    () => (window as unknown as { photoDecoded: boolean }).photoDecoded,
  );
  await page
    .getByRole("button", { name: "Cancel photo upload", exact: true })
    .click();
  await page.evaluate(() =>
    (window as unknown as { releasePhoto: () => void }).releasePhoto(),
  );
  await expect(page.locator('[data-slot="photo-reference"]')).toContainText(
    "Choose one",
  );
  expect(calls).toBe(1);
  await expect(
    page.getByRole("button", { name: "Edit photo", exact: true }),
  ).toBeDisabled();
});
